from data_utils import ( dtl )
df = dtl.build_devicce_conn_df("~/dev-2025/notebook/steps-final/notebooks/public/device_conn.csv")
print(df['nats'])
#print(df.head())
